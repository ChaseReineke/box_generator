import React from 'react';
import './App.css';
import BoxGen from './components/MainComponent';

function App() {
  return (
    <div className="App">
      <BoxGen />
    </div>
  );
}

export default App;